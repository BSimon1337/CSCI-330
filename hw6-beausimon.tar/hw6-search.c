// hw6-search.c
#include "hw6-search.h"
#include <string.h>
#include <stdio.h>

void SEARCH(struct _data *BlackBox, char *name, int size) {
    for (int i = 0; i < size; i++) {
        if (strcmp(BlackBox[i].name, name) == 0) {
            printf("Found: %s - %ld\n", BlackBox[i].name, BlackBox[i].number);
            return;
        }
    }
    printf("Name not found: %s\n", name);
}

