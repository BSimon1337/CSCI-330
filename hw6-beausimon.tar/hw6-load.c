// hw6-load.c
#include "hw6-load.h"
#include <stdlib.h>
#include <string.h>

struct _data *LOAD(FILE *stream, int size) {
    if (stream == NULL) {
        printf("Error: Invalid file stream.\n");
        return NULL;
    }
    struct _data *BlackBox = (struct _data *)malloc(size * sizeof(struct _data));
    for (int i = 0; i < size; i++) {
        BlackBox[i].name = (char *)malloc(50 * sizeof(char)); // Assuming max name length
        fscanf(stream, "%49s %ld", BlackBox[i].name, &BlackBox[i].number);
    }
    return BlackBox;
}

