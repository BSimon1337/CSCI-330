// hw6-search.h
#ifndef HW6_SEARCH_H
#define HW6_SEARCH_H

#include "hw6-load.h"
void SEARCH(struct _data *BlackBox, char *name, int size);

#endif

