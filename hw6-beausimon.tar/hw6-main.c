// hw6-main.c
#include "hw6-main.h"

int main() {
    FILE *file = fopen("hw5.data", "r");
    if (file == NULL) {
        printf("Error: Could not open file.\n");
        return 1;
    }

    int size = SCAN(&file);
    struct _data *data = LOAD(file, size);

    char name[50];
    printf("Enter a name to search: ");
    scanf("%49s", name);
    SEARCH(data, name, size);

    FREE(data, size);
    fclose(file);

    return 0;
}

