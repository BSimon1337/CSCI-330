// hw6-free.c
#include "hw6-free.h"
#include <stdlib.h>

void FREE(struct _data *BlackBox, int size) {
    for (int i = 0; i < size; i++) {
        free(BlackBox[i].name);
    }
    free(BlackBox);
}

