// hw6-scan.h
#ifndef HW6_SCAN_H
#define HW6_SCAN_H

#include <stdio.h>
int SCAN(FILE **stream);

#endif

