// hw6-free.h
#ifndef HW6_FREE_H
#define HW6_FREE_H

#include "hw6-load.h"
void FREE(struct _data *BlackBox, int size);

#endif

