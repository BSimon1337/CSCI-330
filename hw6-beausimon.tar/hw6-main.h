// hw6-main.h
#ifndef HW6_MAIN_H
#define HW6_MAIN_H

#include "hw6-scan.h"
#include "hw6-load.h"
#include "hw6-search.h"
#include "hw6-free.h"
#include <stdio.h>

#endif

