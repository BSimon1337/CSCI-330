// hw6-scan.c
#include "hw6-scan.h"
#include <stdio.h>

int SCAN(FILE **stream) {
    if (*stream == NULL) {
        printf("Error: Unable to open file stream.\n");
        return -1;
    }
    int line_count = 0;
    char ch;
    while ((ch = fgetc(*stream)) != EOF) {
        if (ch == '\n') {
            line_count++;
        }
    }
    rewind(*stream);
    return line_count;
}

